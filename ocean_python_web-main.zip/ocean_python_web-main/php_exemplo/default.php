<?php

$conteudo = "Teste" . PHP_EOL;

echo $conteudo;